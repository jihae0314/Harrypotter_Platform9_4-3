package harrypotter.index;

public class book {
	private int magic_ip;
	private String Hname;
	private String Ename;
	private String Meaning;
	private int Readcount;
	private String Type;
	public int getMagic_ip() {
		return magic_ip;
	}
	public void setMagic_ip(int magic_ip) {
		this.magic_ip = magic_ip;
	}
	public String getHname() {
		return Hname;
	}
	public void setHname(String hname) {
		Hname = hname;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public String getMeaning() {
		return Meaning;
	}
	public void setMeaning(String meaning) {
		Meaning = meaning;
	}
	public int getReadcount() {
		return Readcount;
	}
	public void setReadcount(int readcount) {
		Readcount = readcount;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
}
